#!/bin/bash
docker kill VotingWeb
docker kill VotingData
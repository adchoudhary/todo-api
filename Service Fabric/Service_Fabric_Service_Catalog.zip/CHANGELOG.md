## Service Fabric Service Catalog Change Log

<a name="0.8.8"></a>
# 0.8.0 (2018-03-15)

*Features*

* Works with standard OSB API implementations
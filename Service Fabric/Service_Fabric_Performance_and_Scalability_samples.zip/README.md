---
languages:
- csharp
products:
- azure
page_type: sample
description: "Samples to illustrate the performance and scalability of Service Fabric."
---

# Service Fabric Performance and Scalability samples
This repository contains samples to illustrate the performance and scalability of Service Fabric. Each sample has its own readme file that contains more information about it.

## More information
The [Service Fabric documentation](http://aka.ms/servicefabricdocs) includes a rich set of tutorials and conceptual articles on Service Fabric.
